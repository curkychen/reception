AppControl.controller('reception', ['$scope', '$http', function($scope, $http){
	$http.get('partials/get/get_reception.php').success(function(data){
		$scope.receptionList = data;
	});

	$http.get('partials/get/get_reception_inactive.php').success(function(data){
		$scope.receptionInactiveList = data;
	});

	//removes image from the database
	$scope.remove = function(name){
		$.ajax({
        url: 'partials/reception/delete.php',
        type: "POST",
       	data: {'name':name
        	},
        success: function (response, xhr) {
        	location.reload(true);
        },
        error: function(jqXHR, textStatus, errorThrown) {
           console.log(textStatus, errorThrown);
        }


    	});
	}

	$scope.check = function(name){
		var checkstatus = true;


		if (document.getElementById(name).value=="true"){
			document.getElementById(name).value = "false";
			console.log("check!");
			checkstatus = 0;
		}

		else {
			document.getElementById(name).value="true";
			console.log("uncheck");
			checkstatus = 1;
		}
			}
			


}]);
			