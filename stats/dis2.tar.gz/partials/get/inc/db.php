<?php
$hostname="cetus.stat.cmu.edu";
$user="dis";
$password="JwT";
$database="dis";
?>