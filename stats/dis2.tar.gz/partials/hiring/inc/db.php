<?php
$server="cetus.stat.cmu.edu";
$user="dis";
$password="JwT$1915!";
$database="dis";
?>
