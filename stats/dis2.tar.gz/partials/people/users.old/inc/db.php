<?php

$server="localhost";
$user="dis";
$password="RaF$1890!";
$database="dis";

?>