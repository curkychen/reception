<?php
$hostname="cetus.stat.cmu.edu";
$user="dis";
$password="RaF$1890!";
$database="dis";

?>